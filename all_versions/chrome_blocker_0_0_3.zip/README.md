﻿# Chrome Blocker
 
 This chrome extension allows users to block webistes they don't want to see.
